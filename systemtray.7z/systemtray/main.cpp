#include <QApplication>
#include "systemtray.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // Создание и показ системного трея
    SystemTray trayMenu;
    trayMenu.show();

    return app.exec();
}
