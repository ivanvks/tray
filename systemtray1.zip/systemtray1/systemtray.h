#ifndef SYSTEMTRAY_H
#define SYSTEMTRAY_H

#include <QSystemTrayIcon>
#include <QMenu>
#include <QWidgetAction>
#include <QPushButton>
#include <QLabel>
#include <QString>


class SystemTray : public QSystemTrayIcon
{
    Q_OBJECT
public:
    explicit SystemTray(QObject *parent = nullptr);
    ~SystemTray();

protected:
    bool eventFilter(QObject *obj, QEvent *event) override;

private:
    QWidget* m_action1Widget;
    QWidgetAction* m_action1WidgetAction;
    QPushButton* m_action1Label;

    QWidget* m_action2Widget;
    QWidgetAction* m_action2WidgetAction;
    QPushButton* m_action2Label;
    QString myStyleSheet;
    QMenu* m_trayMenu;
    QWidget* m_topWidget;
    QWidgetAction* m_topWidgetAction;
    QWidgetAction* m_topWidgetAction2;
    QLabel* m_topLabel;
    QPushButton* m_homeBtn;
    QLabel* m_homeBtn2;

    QWidget* m_bottomWidget;
    QWidgetAction* m_bottomWidgetAction;
    QPushButton* m_updateBtn;
    QPushButton* m_aboutBtn;
    QPushButton* m_exitBtn;

    void createTopWidget();
    void createTopWidget2();
    void createBottomWidget();
    void createAction2Widget();
    void createAction1Widget();
public slots:
    void updateIcon(bool showMessage); // Обновление иконки в зависимости от флага showMessage

};

#endif // SYSTEMTRAY_H
