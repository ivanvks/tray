#include "systemtray.h"
#include <QDebug>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QHBoxLayout>
#include <QApplication>
#include <QPainter>

SystemTray::SystemTray(QObject *parent) : QSystemTrayIcon(parent)
{
    // Установка стиля для m_trayMenu
    myStyleSheet = "QMenu {"
                   "background: white;"
                   "border: 1px solid lightgray;"
                   "}"
                   "QMenu::item {"
                   "padding: 0px 20px 0px 20px;"
                   "margin-left: 5px;"
                   "height: 25px;"
                   "}"
                   "QMenu::item:selected:enabled {"
                   "background: lightgray;"
                   "color: white;"
                   "}"
                   "QMenu::separator {"
                   "height: 1px;"
                   "background: lightgray;"
                   "margin: 2px 0px 2px 0px;"
                   "}"
                   "QMenu::item:selected:!enabled {"
                   "background: transparent;"
                   "}"
                   "QPushButton#TrayButton {"
                   "border: none;"
                   "background: transparent;"
                   "}"
                   "QPushButton#TrayButton:hover {"
                   "background: rgb(233, 237, 252);"
                   "color: rgb(52, 120, 152);"
                   "}";

    m_trayMenu = new QMenu();
    m_trayMenu->setStyleSheet(myStyleSheet); // Применяем стиль к m_trayMenu
    qDebug() << "Примененный стиль:" << m_trayMenu->styleSheet();

                QIcon trayIcon(":/menu/tray_icon");
    this->setIcon(trayIcon);

    // Создание и установка пользовательских виджетов
    createTopWidget();
    createTopWidget2();
    createAction1Widget();
    createAction2Widget();
    createBottomWidget();

    // Добавление пользовательских виджетов в меню
    m_trayMenu->addAction(m_topWidgetAction);
    m_trayMenu->addSeparator();
    m_trayMenu->addAction(m_topWidgetAction2);
    m_trayMenu->addSeparator();
    m_trayMenu->addAction(m_action1WidgetAction);
    m_trayMenu->addSeparator();
    m_trayMenu->addAction(m_action2WidgetAction);
    m_trayMenu->addSeparator();
    m_trayMenu->addAction(m_bottomWidgetAction);

    // Установка меню для иконки трея
    this->setContextMenu(m_trayMenu);
}

SystemTray::~SystemTray()
{
    delete m_trayMenu;
}

bool SystemTray::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == m_topWidget && event->type() == QEvent::Paint)
    {
        qDebug() << "Рисуем верхний виджет";
        QPainter painter(m_topWidget);
        painter.setPen(Qt::NoPen);
        painter.setBrush(QColor(42, 120, 192));
        painter.drawRect(m_topWidget->rect());
    }
    return QSystemTrayIcon::eventFilter(obj, event);
}

void SystemTray::createTopWidget()
{
    m_topWidget = new QWidget();
    m_topWidgetAction = new QWidgetAction(m_trayMenu);
    m_topLabel = new QLabel(QStringLiteral(" Название программы..."));
    m_topLabel->setObjectName(QStringLiteral("WhiteLabel"));
    m_homeBtn = new QPushButton(QStringLiteral("Главное окно программы"));
    m_homeBtn->setCursor(Qt::PointingHandCursor);
    m_homeBtn->setObjectName(QStringLiteral("WhiteLabel"));

    QVBoxLayout* m_topLayout = new QVBoxLayout();
    m_topLayout->addWidget(m_topLabel, 0, Qt::AlignLeft|Qt::AlignVCenter);
    m_topLayout->addWidget(m_homeBtn, 0, Qt::AlignRight|Qt::AlignVCenter);

    m_topLayout->setSpacing(5);
    m_topLayout->setContentsMargins(5, 5, 5, 5);

    m_topWidget->setLayout(m_topLayout);
    m_topWidget->installEventFilter(this);
    m_topWidgetAction->setDefaultWidget(m_topWidget);
  //  connect(m_homeBtn, &QPushButton::clicked, /*QApplication::instance(), &QApplication::quit*/);
}
void SystemTray::createTopWidget2()/// переделать под кнопки со сменными иконками
{
    m_topWidget = new QWidget();
    m_topWidgetAction2 = new QWidgetAction(m_trayMenu);
    m_topLabel = new QLabel(QStringLiteral(" Состояние подключения"));
    m_topLabel->setObjectName(QStringLiteral("WhiteLabel"));

    m_homeBtn2 = new QLabel(QStringLiteral("Ссылка"));
    m_homeBtn2->setCursor(Qt::PointingHandCursor);
    m_homeBtn2->setObjectName(QStringLiteral("WhiteLabel"));
    /// Сюда запихать светофорику [ ASUV ] [ POVZ ]

    QVBoxLayout* m_topLayout = new QVBoxLayout();
    m_topLayout->addWidget(m_topLabel, 0, Qt::AlignLeft|Qt::AlignVCenter);
    m_topLayout->addWidget(m_homeBtn2, 0, Qt::AlignRight|Qt::AlignVCenter);

    m_topLayout->setSpacing(5);
    m_topLayout->setContentsMargins(5, 5, 5, 5);

    m_topWidget->setLayout(m_topLayout);
    m_topWidget->installEventFilter(this);
    m_topWidgetAction2->setDefaultWidget(m_topWidget);
}
void SystemTray::createBottomWidget()
{
    m_bottomWidget = new QWidget();
    m_bottomWidgetAction = new QWidgetAction(m_trayMenu);

    m_updateBtn = new QPushButton(QIcon(":/menu/update"), QStringLiteral("Обновить"));
    m_updateBtn->setObjectName(QStringLiteral("TrayButton"));
    m_updateBtn->setFixedSize(80, 25);
    m_updateBtn->setStyleSheet(myStyleSheet);

    m_aboutBtn = new QPushButton(QIcon(":/menu/about"), QStringLiteral("Информация"));
    m_aboutBtn->setObjectName(QStringLiteral("TrayButton"));
    m_aboutBtn->setFixedSize(100, 25);
    m_aboutBtn->setStyleSheet(myStyleSheet);

    m_exitBtn = new QPushButton(QIcon(":/menu/quit"), QStringLiteral("Выход"));
    m_exitBtn->setObjectName(QStringLiteral("TrayButton"));
    m_exitBtn->setFixedSize(60, 25);
    m_exitBtn->setStyleSheet(myStyleSheet);
    connect(m_exitBtn, &QPushButton::clicked, QApplication::instance(), &QApplication::quit);

    QHBoxLayout* m_bottomLayout = new QHBoxLayout();
    m_bottomLayout->addWidget(m_updateBtn, 0, Qt::AlignCenter);
    m_bottomLayout->addWidget(m_aboutBtn, 0, Qt::AlignCenter);
    m_bottomLayout->addWidget(m_exitBtn, 0, Qt::AlignCenter);

    m_bottomLayout->setSpacing(5);
    m_bottomLayout->setContentsMargins(5,5,5,5);

    m_bottomWidget->setLayout(m_bottomLayout);
    m_bottomWidgetAction->setDefaultWidget(m_bottomWidget);
    qDebug() << "Стиль trayButton:" << m_updateBtn->styleSheet();
}
void SystemTray::createAction1Widget()
{
    m_action1Widget = new QWidget();
    m_action1WidgetAction = new QWidgetAction(m_trayMenu);
/// добавить механизм отрисовки сообщений (анимировать новое входящее сообщение)
    m_action1Label = new QPushButton(QIcon(":/menu/mess"), QStringLiteral("   Свои войска           "));
    m_action1Label->setObjectName(QStringLiteral("TrayButton"));
    m_action1Label->setFixedSize(250, 25);
   // m_action1Label->setStyleSheet(myStyleSheet);
    m_action1Label->setStyleSheet("QPushButton#TrayButton {"
                                      "border: none;"
                                      "background: transparent;"
                                      "padding-right: 107px;" // Set the desired spacing between the icon and the text
                                      "}"
                                      "QPushButton#TrayButton:hover {"
                                      "background: rgb(233, 237, 252);"
                                      "color: rgb(52, 120, 152);"
                                      "}");


    QVBoxLayout* m_action1Layout = new QVBoxLayout();
    m_action1Layout->addWidget(m_action1Label, 0, Qt::AlignLeft | Qt::AlignVCenter);

    m_action1Layout->setSpacing(5);
    m_action1Layout->setContentsMargins(5, 5, 5, 5);

    m_action1Widget->setLayout(m_action1Layout);
    m_action1WidgetAction->setDefaultWidget(m_action1Widget);
}


void SystemTray::createAction2Widget()
{
    m_action2Widget = new QWidget();
    m_action2WidgetAction = new QWidgetAction(m_trayMenu);
    /// добавить механизм отрисовки сообщений (анимировать новое входящее сообщение)
    m_action2Label = new QPushButton(QIcon(":/menu/mess"), QStringLiteral("   Войска противника     "));
    m_action2Label->setObjectName(QStringLiteral("TrayButton"));
    m_action2Label->setFixedSize(250, 25);
   // m_action2Label->setStyleSheet(myStyleSheet);
    m_action2Label->setStyleSheet("QPushButton#TrayButton {"
                                      "border: none;"
                                      "background: transparent;"
                                      "padding-right: 90px;" // Set the desired spacing between the icon and the text
                                      "}"
                                      "QPushButton#TrayButton:hover {"
                                      "background: rgb(233, 237, 252);"
                                      "color: rgb(52, 120, 152);"
                                      "}");

    QVBoxLayout* m_action2Layout = new QVBoxLayout();
    m_action2Layout->addWidget(m_action2Label, 0, Qt::AlignLeft | Qt::AlignVCenter);

    m_action2Layout->setSpacing(5);
    m_action2Layout->setContentsMargins(5, 5, 5, 5);

    m_action2Widget->setLayout(m_action2Layout);
    m_action2WidgetAction->setDefaultWidget(m_action2Widget);
    }
void SystemTray::updateIcon(bool showMessage)
{
    QIcon newIcon = showMessage ? QIcon(":/menu/mess_on") : QIcon(":/menu/mess");
    m_action2Label->setIcon(newIcon);
}
/////////////////////////// в посулателе сообщений

//  внутри другого класса:
// меняем иконку на QIcon(":/menu/mess_on"): пришло сообщение
systemTrayObject->updateIcon(true);

// изменить иконку на QIcon(":/menu/mess"):
systemTrayObject->updateIcon(false);
